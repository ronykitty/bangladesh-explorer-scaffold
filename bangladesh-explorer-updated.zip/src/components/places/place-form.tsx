import { useEffect, useMemo, useState } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Modal } from '@/components/ui/modal'
import { SearchableSelect } from '@/components/ui/searchable-select'
import { useDivisions, useDistricts, useUpazilas, useCategories } from '@/hooks/use-reference-data'
import { useCreatePlace, useUpdatePlace, type PlaceWithRelations } from '@/hooks/use-places'
import { useAuth } from '@/lib/auth-context'
import type { PlaceStatus } from '@/types/database'

const placeSchema = z.object({
  division_id: z.string().min(1, 'বিভাগ বেছে নাও'),
  district_id: z.string().min(1, 'জেলা বেছে নাও'),
  upazila_id: z.string().optional(),
  union_village: z.string().optional(),
  category_id: z.string().min(1, 'ক্যাটাগরি বেছে নাও'),
  name: z.string().min(1, 'জায়গার নাম লেখো'),
  status: z.enum(['wishlist', 'planned', 'visited', 'revisited']),
  description: z.string().optional(),
  photo_url: z.string().url('সঠিক লিংক দাও').optional().or(z.literal('')),
  google_maps_url: z.string().url('সঠিক লিংক দাও').optional().or(z.literal('')),
  personal_rating: z.string().optional(),
  target_date: z.string().optional(),
})

type PlaceFormValues = z.infer<typeof placeSchema>

const STATUS_OPTIONS: { value: PlaceStatus; label: string; icon: string; tone: string; toneBg: string }[] = [
  { value: 'wishlist', label: 'যেতে চাই', icon: '⭐', tone: '--wishlist', toneBg: '--wishlist-bg' },
  { value: 'planned', label: 'পরিকল্পিত', icon: '🗓', tone: '--planned', toneBg: '--planned-bg' },
  { value: 'visited', label: 'ঘুরে এসেছি', icon: '✅', tone: '--visited', toneBg: '--visited-bg' },
  { value: 'revisited', label: 'আবার গিয়েছি', icon: '🔁', tone: '--revisited', toneBg: '--revisited-bg' },
]

interface PlaceFormProps {
  open: boolean
  onClose: () => void
  editingPlace?: PlaceWithRelations | null
  presetCategoryId?: string
  presetStatus?: PlaceStatus
}

export function PlaceForm({ open, onClose, editingPlace, presetCategoryId, presetStatus }: PlaceFormProps) {
  const { user } = useAuth()
  const { data: divisions } = useDivisions()
  const { data: districts } = useDistricts()
  const { data: upazilas } = useUpazilas()
  const { data: categories } = useCategories()
  const createPlace = useCreatePlace()
  const updatePlace = useUpdatePlace()
  const [serverError, setServerError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    control,
    watch,
    setValue,
    reset,
    formState: { errors },
  } = useForm<PlaceFormValues>({
    resolver: zodResolver(placeSchema),
    defaultValues: {
      division_id: '',
      district_id: '',
      upazila_id: '',
      union_village: '',
      category_id: presetCategoryId ?? '',
      name: '',
      status: presetStatus ?? 'wishlist',
      description: '',
      photo_url: '',
      google_maps_url: '',
      personal_rating: '',
      target_date: '',
    },
  })

  const selectedDivisionId = watch('division_id')
  const selectedDistrictId = watch('district_id')

  const filteredDistricts = useMemo(
    () => (districts ?? []).filter((d) => d.division_id === selectedDivisionId),
    [districts, selectedDivisionId]
  )

  const filteredUpazilas = useMemo(
    () => (upazilas ?? []).filter((u) => u.district_id === selectedDistrictId),
    [upazilas, selectedDistrictId]
  )

  useEffect(() => {
    if (!open) return
    if (editingPlace) {
      reset({
        division_id: editingPlace.district.division_id,
        district_id: editingPlace.district_id,
        upazila_id: editingPlace.upazila_id ?? '',
        union_village: editingPlace.union_village ?? '',
        category_id: editingPlace.category_id,
        name: editingPlace.name,
        status: editingPlace.status,
        description: editingPlace.description ?? '',
        photo_url: editingPlace.photo_url ?? '',
        google_maps_url: editingPlace.google_maps_url ?? '',
        personal_rating: editingPlace.personal_rating != null ? String(editingPlace.personal_rating) : '',
        target_date: editingPlace.target_date ?? '',
      })
    } else {
      reset({
        division_id: '',
        district_id: '',
        upazila_id: '',
        union_village: '',
        category_id: presetCategoryId ?? '',
        name: '',
        status: presetStatus ?? 'wishlist',
        description: '',
        photo_url: '',
        google_maps_url: '',
        personal_rating: '',
        target_date: '',
      })
    }
    setServerError(null)
  }, [open, editingPlace, presetCategoryId, presetStatus, reset])

  const onSubmit = async (values: PlaceFormValues) => {
    if (!user) return
    setServerError(null)
    // The upazila is picked from the authoritative list, never typed. We
    // store both upazila_id (the real FK, for accurate coverage tracking)
    // and upazila_name (kept in sync from the selected upazila's Bengali
    // name) so existing search/dashboard code that still reads
    // upazila_name as free text keeps working without changes.
    const selectedUpazila = (upazilas ?? []).find((u) => u.id === values.upazila_id)
    const input = {
      category_id: values.category_id,
      district_id: values.district_id,
      upazila_id: values.upazila_id || null,
      upazila_name: selectedUpazila?.name_bn ?? selectedUpazila?.name_en ?? null,
      union_village: values.union_village || null,
      name: values.name,
      description: values.description || null,
      status: values.status,
      photo_url: values.photo_url || null,
      google_maps_url: values.google_maps_url || null,
      personal_rating: values.personal_rating ? Number(values.personal_rating) : null,
      target_date: values.target_date || null,
    }
    try {
      if (editingPlace) {
        await updatePlace.mutateAsync({ id: editingPlace.id, input })
      } else {
        await createPlace.mutateAsync({ input, userId: user.id })
      }
      onClose()
    } catch (err) {
      setServerError(err instanceof Error ? err.message : 'সংরক্ষণ ব্যর্থ হয়েছে')
    }
  }

  const submitting = createPlace.isPending || updatePlace.isPending
  const inputClasses =
    'w-full rounded-xl border-2 border-[hsl(var(--line))] bg-white/80 px-3.5 py-2.5 text-base outline-none transition-colors focus:border-[hsl(var(--accent))] focus:ring-4 focus:ring-[hsl(var(--accent)/0.15)]'
  const labelClasses = 'mb-1.5 flex items-center gap-1.5 text-sm font-semibold text-[hsl(var(--ink))]'
  const sectionTitleClasses = 'mb-3 mt-5 flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-[hsl(var(--accent-dark))] first:mt-0'

  return (
    <Modal open={open} onClose={onClose} title={editingPlace ? '✏️ এন্ট্রি এডিট করো' : '📍 নতুন এন্ট্রি যোগ করো'}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex max-h-[75vh] flex-col gap-1 overflow-y-auto pr-1" noValidate>
        <p className={sectionTitleClasses}>🗺️ অবস্থান</p>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelClasses}>বিভাগ</label>
            <Controller
              control={control}
              name="division_id"
              render={({ field }) => (
                <SearchableSelect
                  options={(divisions ?? []).map((d) => ({ value: d.id, label: d.name_bn }))}
                  value={field.value}
                  onChange={(val) => {
                    field.onChange(val)
                    // Changing division invalidates any previously chosen
                    // district/upazila that no longer belongs to it.
                    setValue('district_id', '')
                    setValue('upazila_id', '')
                  }}
                  placeholder="বিভাগ বেছে নাও"
                  searchPlaceholder="বিভাগ খুঁজুন..."
                />
              )}
            />
            {errors.division_id && <p className="mt-1 text-xs font-semibold text-[hsl(var(--danger))]">{errors.division_id.message}</p>}
          </div>
          <div>
            <label className={labelClasses}>জেলা</label>
            <Controller
              control={control}
              name="district_id"
              render={({ field }) => (
                <SearchableSelect
                  options={filteredDistricts.map((d) => ({ value: d.id, label: d.name_bn }))}
                  value={field.value}
                  onChange={(val) => {
                    field.onChange(val)
                    setValue('upazila_id', '')
                  }}
                  placeholder="জেলা বেছে নাও"
                  searchPlaceholder="জেলা খুঁজুন..."
                  disabled={!selectedDivisionId}
                  disabledMessage="আগে বিভাগ বেছে নাও"
                />
              )}
            />
            {errors.district_id && <p className="mt-1 text-xs font-semibold text-[hsl(var(--danger))]">{errors.district_id.message}</p>}
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-3">
          <div>
            <label className={labelClasses}>উপজেলা</label>
            <Controller
              control={control}
              name="upazila_id"
              render={({ field }) => (
                <SearchableSelect
                  options={filteredUpazilas.map((u) => ({ value: u.id, label: u.name_bn || u.name_en }))}
                  value={field.value ?? ''}
                  onChange={field.onChange}
                  placeholder="উপজেলা বেছে নাও"
                  searchPlaceholder="উপজেলা খুঁজুন..."
                  disabled={!selectedDistrictId}
                  disabledMessage="আগে জেলা বেছে নাও"
                />
              )}
            />
          </div>
          <div>
            <label className={labelClasses}>ইউনিয়ন / গ্রাম / এলাকা</label>
            <input className={inputClasses} placeholder="ঐচ্ছিক" {...register('union_village')} />
          </div>
        </div>

        <p className={sectionTitleClasses}>🏷️ বিবরণ</p>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelClasses}>ক্যাটাগরি</label>
            <select className={inputClasses} {...register('category_id')}>
              <option value="">বেছে নাও</option>
              {categories?.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.icon} {c.name_bn}
                </option>
              ))}
            </select>
            {errors.category_id && <p className="mt-1 text-xs font-semibold text-[hsl(var(--danger))]">{errors.category_id.message}</p>}
          </div>
          <div>
            <label className={labelClasses}>জায়গার নাম</label>
            <input className={inputClasses} placeholder="যেমন: মেঘনা ঘাট" {...register('name')} />
            {errors.name && <p className="mt-1 text-xs font-semibold text-[hsl(var(--danger))]">{errors.name.message}</p>}
          </div>
        </div>

        <p className={sectionTitleClasses}>📌 অবস্থা</p>
        <Controller
          control={control}
          name="status"
          render={({ field }) => (
            <div className="grid grid-cols-4 gap-2">
              {STATUS_OPTIONS.map((opt) => {
                const active = field.value === opt.value
                return (
                  <button
                    type="button"
                    key={opt.value}
                    onClick={() => field.onChange(opt.value)}
                    className="rounded-xl border-2 px-2 py-3 text-center text-sm font-bold transition-all"
                    style={
                      active
                        ? {
                            borderColor: `hsl(var(${opt.tone}))`,
                            backgroundColor: `hsl(var(${opt.toneBg}))`,
                            color: `hsl(var(${opt.tone}))`,
                          }
                        : { borderColor: 'hsl(var(--line))', color: 'hsl(var(--ink-soft))' }
                    }
                  >
                    <div className="text-2xl leading-none">{opt.icon}</div>
                    <div className="mt-1">{opt.label}</div>
                  </button>
                )
              })}
            </div>
          )}
        />

        <p className={sectionTitleClasses}>🔗 আরও তথ্য</p>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelClasses}>ছবির লিংক (ঐচ্ছিক)</label>
            <input className={inputClasses} placeholder="https://..." {...register('photo_url')} />
            {errors.photo_url && <p className="mt-1 text-xs font-semibold text-[hsl(var(--danger))]">{errors.photo_url.message}</p>}
          </div>
          <div>
            <label className={labelClasses}>Google Maps লিংক (ঐচ্ছিক)</label>
            <input className={inputClasses} placeholder="https://maps.google.com/..." {...register('google_maps_url')} />
            {errors.google_maps_url && (
              <p className="mt-1 text-xs font-semibold text-[hsl(var(--danger))]">{errors.google_maps_url.message}</p>
            )}
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-3">
          <div>
            <label className={labelClasses}>⭐ নিজের রেটিং (০–৫, ঐচ্ছিক)</label>
            <input type="number" min={0} max={5} step={0.5} className={inputClasses} {...register('personal_rating')} />
          </div>
          <div>
            <label className={labelClasses}>🗓 পরিকল্পিত তারিখ (ঐচ্ছিক)</label>
            <input type="date" className={inputClasses} {...register('target_date')} />
          </div>
        </div>

        <div className="mt-3">
          <label className={labelClasses}>বিস্তারিত / বর্ণনা (ঐচ্ছিক)</label>
          <textarea
            className={inputClasses}
            rows={3}
            placeholder="কেন যেতে চাও, ইতিহাস, কীভাবে যাবে..."
            {...register('description')}
          />
        </div>

        {serverError && (
          <p className="mt-3 rounded-xl bg-[hsl(var(--danger)/0.12)] px-3.5 py-2.5 text-sm font-semibold text-[hsl(var(--danger))]">
            {serverError}
          </p>
        )}

        <div className="sticky bottom-0 -mx-1 mt-4 flex justify-end gap-2 bg-[hsl(var(--card))] px-1 pb-1 pt-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border-2 border-[hsl(var(--line))] px-5 py-2.5 text-sm font-semibold text-[hsl(var(--ink-soft))] transition-colors hover:bg-[hsl(var(--line)/0.4)]"
          >
            বাতিল
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="rounded-xl bg-[hsl(var(--accent))] px-6 py-2.5 text-sm font-bold text-white shadow-sm transition-all hover:brightness-95 disabled:opacity-60"
          >
            {submitting ? 'সংরক্ষণ হচ্ছে...' : editingPlace ? 'আপডেট করো' : 'সংরক্ষণ করো'}
          </button>
        </div>
      </form>
    </Modal>
  )
}
