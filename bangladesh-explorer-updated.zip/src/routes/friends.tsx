// src/routes/friends.tsx
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Loader2, UserPlus, MessageCircle, UserMinus, Check, X } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { PageHeader } from '@/components/layout/page-header'
import { useFriendships } from '@/hooks/use-friendships'
import { useCurrentUser } from '@/hooks/use-current-user'

type ProfileLite = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

function Avatar({ profile }: { profile?: ProfileLite }) {
  if (profile?.avatar_url) {
    return (
      <img
        src={profile.avatar_url}
        alt=""
        className="h-11 w-11 rounded-full border border-[hsl(var(--line))] object-cover"
      />
    )
  }
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[hsl(var(--accent))]/15 font-serif text-[hsl(var(--accent-dark))]">
      {(profile?.full_name ?? profile?.username ?? '?').charAt(0).toUpperCase()}
    </div>
  )
}

// friendship রো-গুলো থেকে পাওয়া user id-গুলোর প্রোফাইল একসাথে লোড করে একটা map রিটার্ন করে
function useProfilesFor(userIds: string[]) {
  const [map, setMap] = useState<Record<string, ProfileLite>>({})
  const uniqueIds = [...new Set(userIds)].filter(Boolean).sort().join(',')

  useEffect(() => {
    const ids = uniqueIds ? uniqueIds.split(',') : []
    if (ids.length === 0) {
      setMap({})
      return
    }
    supabase
      .from('profiles')
      .select('id, username, full_name, avatar_url')
      .in('id', ids)
      .then(({ data, error }) => {
        if (error) {
          console.error('profiles batch fetch failed:', error.message)
          return
        }
        const next: Record<string, ProfileLite> = {}
        for (const p of data ?? []) next[p.id] = p
        setMap(next)
      })
  }, [uniqueIds])

  return map
}

export default function FriendsPage() {
  const { userId } = useCurrentUser()
  const { accepted, incomingPending, outgoingPending, respondToRequest, removeFriendship, loading } =
    useFriendships()

  const profiles = useProfilesFor(
    [...accepted, ...incomingPending, ...outgoingPending].flatMap((r) => [r.requester_id, r.addressee_id])
  )

  return (
    <div>
      <div className="flex items-center justify-between">
        <PageHeader title="ফ্রেন্ডস" subtitle="আপনার ভ্রমণ-সঙ্গীরা এবং তাদের সাথে সংযোগ" />
        <Link
          to="/find-friends"
          className="flex items-center gap-1.5 rounded-full bg-[hsl(var(--accent))] px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:opacity-90"
        >
          <UserPlus className="h-4 w-4" /> খুঁজুন
        </Link>
      </div>

      {loading ? (
        <p className="mt-6 flex items-center gap-2 text-sm text-[hsl(var(--ink-soft))]">
          <Loader2 className="h-4 w-4 animate-spin" /> লোড হচ্ছে...
        </p>
      ) : (
        <div className="mt-2 flex flex-col gap-6">
          {incomingPending.length > 0 && (
            <section className="glass rounded-xl p-4">
              <h2 className="font-serif text-base text-[hsl(var(--accent-dark))]">
                রিকোয়েস্ট এসেছে ({incomingPending.length})
              </h2>
              <div className="mt-3 flex flex-col gap-2">
                {incomingPending.map((r) => {
                  const other = profiles[r.requester_id]
                  return (
                    <div
                      key={r.id}
                      className="flex items-center justify-between rounded-lg border border-[hsl(var(--line))] px-3 py-2"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar profile={other} />
                        <span className="text-sm font-medium text-[hsl(var(--ink))]">
                          {other?.full_name || other?.username || '...'}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => respondToRequest(r.id, 'accepted')}
                          className="flex items-center gap-1 rounded-full bg-[hsl(var(--visited))] px-3 py-1.5 text-xs font-medium text-white"
                        >
                          <Check className="h-3.5 w-3.5" /> একসেপ্ট
                        </button>
                        <button
                          onClick={() => respondToRequest(r.id, 'declined')}
                          className="flex items-center gap-1 rounded-full border border-[hsl(var(--line))] px-3 py-1.5 text-xs font-medium text-[hsl(var(--ink-soft))]"
                        >
                          <X className="h-3.5 w-3.5" /> বাতিল
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </section>
          )}

          <section className="glass rounded-xl p-4">
            <h2 className="font-serif text-base text-[hsl(var(--accent-dark))]">
              আপনার ফ্রেন্ডস ({accepted.length})
            </h2>
            <div className="mt-3 flex flex-col gap-2">
              {accepted.length === 0 && (
                <p className="text-sm text-[hsl(var(--ink-soft))]">
                  এখনো কোনো ফ্রেন্ড নেই। "খুঁজুন" বাটনে ক্লিক করে বন্ধুদের খুঁজে নিন।
                </p>
              )}
              {accepted.map((r) => {
                const otherUserId = r.requester_id === userId ? r.addressee_id : r.requester_id
                const other = profiles[otherUserId]
                return (
                  <div
                    key={r.id}
                    className="flex items-center justify-between rounded-lg border border-[hsl(var(--line))] px-3 py-2"
                  >
                    <Link to={`/profile/${other?.username}`} className="flex items-center gap-3">
                      <Avatar profile={other} />
                      <span className="text-sm font-medium text-[hsl(var(--ink))] hover:underline">
                        {other?.full_name || other?.username || '...'}
                      </span>
                    </Link>
                    <div className="flex gap-2">
                      <Link
                        to={`/messages/${otherUserId}`}
                        className="flex items-center gap-1 rounded-full bg-[hsl(var(--accent))] px-3 py-1.5 text-xs font-medium text-white"
                      >
                        <MessageCircle className="h-3.5 w-3.5" /> মেসেজ
                      </Link>
                      <button
                        onClick={() => removeFriendship(r.id)}
                        className="flex items-center gap-1 rounded-full border border-[hsl(var(--line))] px-3 py-1.5 text-xs font-medium text-[hsl(var(--ink-soft))]"
                      >
                        <UserMinus className="h-3.5 w-3.5" /> আনফ্রেন্ড
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          </section>

          {outgoingPending.length > 0 && (
            <section className="glass rounded-xl p-4">
              <h2 className="font-serif text-base text-[hsl(var(--accent-dark))]">
                পাঠানো রিকোয়েস্ট ({outgoingPending.length})
              </h2>
              <div className="mt-3 flex flex-col gap-2">
                {outgoingPending.map((r) => {
                  const other = profiles[r.addressee_id]
                  return (
                    <div
                      key={r.id}
                      className="flex items-center justify-between rounded-lg border border-[hsl(var(--line))] px-3 py-2"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar profile={other} />
                        <span className="text-sm text-[hsl(var(--ink))]">
                          {other?.full_name || other?.username || '...'}
                        </span>
                      </div>
                      <span className="text-xs text-[hsl(var(--ink-soft))]">পেন্ডিং</span>
                    </div>
                  )
                })}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  )
}
