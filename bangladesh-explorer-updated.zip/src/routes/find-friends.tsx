// src/routes/find-friends.tsx
import { Loader2, Search } from 'lucide-react'
import { PageHeader } from '@/components/layout/page-header'
import { useUserSearch, useFriendships } from '@/hooks/use-friendships'
import { useCurrentUser } from '@/hooks/use-current-user'

export default function FindFriendsPage() {
  const { query, setQuery, results, loading } = useUserSearch()
  const { statusWith, sendRequest } = useFriendships()
  const { userId } = useCurrentUser()

  return (
    <div className="mx-auto max-w-lg">
      <PageHeader title="ফ্রেন্ডস খুঁজুন" subtitle="ইউজারনেম বা নাম দিয়ে সার্চ করুন" />

      <div className="glass rounded-xl p-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[hsl(var(--ink-soft))]" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="username বা নাম লিখুন..."
            autoFocus
            className="w-full rounded-full border border-[hsl(var(--line))] bg-transparent py-2.5 pl-9 pr-3 text-sm text-[hsl(var(--ink))] outline-none focus:border-[hsl(var(--accent))]"
          />
        </div>

        <div className="mt-4 flex flex-col gap-2">
          {loading && (
            <p className="flex items-center gap-2 text-sm text-[hsl(var(--ink-soft))]">
              <Loader2 className="h-4 w-4 animate-spin" /> খোঁজা হচ্ছে...
            </p>
          )}

          {!loading && query.trim().length >= 2 && results.length === 0 && (
            <p className="text-sm text-[hsl(var(--ink-soft))]">কেউ পাওয়া যায়নি।</p>
          )}

          {query.trim().length < 2 && (
            <p className="text-sm text-[hsl(var(--ink-soft))]">কমপক্ষে ২ অক্ষর লিখুন খোঁজা শুরু করতে।</p>
          )}

          {results.map((profile) => {
            const relation = statusWith(profile.id)
            return (
              <div
                key={profile.id}
                className="flex items-center justify-between rounded-lg border border-[hsl(var(--line))] px-3 py-2"
              >
                <div className="flex items-center gap-3">
                  {profile.avatar_url ? (
                    <img src={profile.avatar_url} alt="" className="h-9 w-9 rounded-full object-cover" />
                  ) : (
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[hsl(var(--accent))]/15 font-serif text-[hsl(var(--accent-dark))]">
                      {(profile.full_name ?? profile.username ?? '?').charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div>
                    <p className="text-sm font-medium text-[hsl(var(--ink))]">
                      {profile.full_name || profile.username}
                    </p>
                    {profile.username && (
                      <p className="text-xs text-[hsl(var(--ink-soft))]">@{profile.username}</p>
                    )}
                  </div>
                </div>

                <FriendActionButton
                  relationStatus={relation?.status}
                  isRequester={relation?.requester_id === userId}
                  onAdd={() => sendRequest(profile.id)}
                />
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function FriendActionButton({
  relationStatus,
  isRequester,
  onAdd,
}: {
  relationStatus?: 'pending' | 'accepted' | 'declined' | 'blocked'
  isRequester: boolean
  onAdd: () => void
}) {
  if (relationStatus === 'accepted') {
    return <span className="text-xs font-medium text-[hsl(var(--visited))]">ফ্রেন্ড</span>
  }
  if (relationStatus === 'pending') {
    return (
      <span className="text-xs text-[hsl(var(--ink-soft))]">
        {isRequester ? 'রিকোয়েস্ট পাঠানো হয়েছে' : 'রিকোয়েস্ট পেন্ডিং'}
      </span>
    )
  }
  if (relationStatus === 'blocked') return null

  return (
    <button
      onClick={onAdd}
      className="rounded-full bg-[hsl(var(--accent))] px-3 py-1.5 text-xs font-medium text-white transition hover:opacity-90"
    >
      Add Friend
    </button>
  )
}
