// src/routes/messages.tsx
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Loader2, MessageCircle } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { PageHeader } from '@/components/layout/page-header'
import { useCurrentUser } from '@/hooks/use-current-user'
import { useFriendships } from '@/hooks/use-friendships'

type ProfileLite = {
  id: string
  username: string | null
  full_name: string | null
  avatar_url: string | null
}

type ConversationSummary = {
  friend: ProfileLite
  lastMessage: string | null
  lastMessageAt: string | null
  unreadCount: number
}

export default function MessagesInboxPage() {
  const { userId } = useCurrentUser()
  const { accepted, loading: friendsLoading } = useFriendships()
  const [summaries, setSummaries] = useState<ConversationSummary[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!userId || friendsLoading) return

    const friendIds = accepted.map((r) => (r.requester_id === userId ? r.addressee_id : r.requester_id))

    if (friendIds.length === 0) {
      setSummaries([])
      setLoading(false)
      return
    }

    let active = true

    async function load() {
      setLoading(true)

      const [{ data: profiles }, { data: messages }] = await Promise.all([
        supabase.from('profiles').select('id, username, full_name, avatar_url').in('id', friendIds),
        supabase
          .from('messages')
          .select('sender_id, receiver_id, content, created_at, read_at')
          .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
          .order('created_at', { ascending: false }),
      ])

      if (!active) return

      const list: ConversationSummary[] = (profiles ?? []).map((p) => {
        const withThisFriend = (messages ?? []).filter(
          (m) =>
            (m.sender_id === p.id && m.receiver_id === userId) ||
            (m.sender_id === userId && m.receiver_id === p.id)
        )
        const last = withThisFriend[0] // already sorted desc
        const unreadCount = withThisFriend.filter(
          (m) => m.sender_id === p.id && m.receiver_id === userId && !m.read_at
        ).length

        return {
          friend: p,
          lastMessage: last?.content ?? null,
          lastMessageAt: last?.created_at ?? null,
          unreadCount,
        }
      })

      // সাম্প্রতিক মেসেজ আগে দেখাও; যাদের সাথে এখনো মেসেজ শুরু হয়নি তারা শেষে
      list.sort((a, b) => {
        if (!a.lastMessageAt) return 1
        if (!b.lastMessageAt) return -1
        return b.lastMessageAt.localeCompare(a.lastMessageAt)
      })

      setSummaries(list)
      setLoading(false)
    }

    load()
    return () => {
      active = false
    }
  }, [userId, friendsLoading, accepted])

  return (
    <div className="mx-auto max-w-lg">
      <PageHeader title="মেসেজ" subtitle="বন্ধুদের সাথে কথোপকথন" />

      {loading ? (
        <p className="flex items-center gap-2 text-sm text-[hsl(var(--ink-soft))]">
          <Loader2 className="h-4 w-4 animate-spin" /> লোড হচ্ছে...
        </p>
      ) : summaries.length === 0 ? (
        <div className="glass rounded-xl p-6 text-center">
          <MessageCircle className="mx-auto h-8 w-8 text-[hsl(var(--ink-soft))]" />
          <p className="mt-3 text-sm text-[hsl(var(--ink-soft))]">
            এখনো কোনো ফ্রেন্ড নেই। আগে{' '}
            <Link to="/find-friends" className="font-medium text-[hsl(var(--accent-dark))] underline">
              ফ্রেন্ড খুঁজুন
            </Link>
            , তারপর মেসেজ করা যাবে।
          </p>
        </div>
      ) : (
        <div className="glass flex flex-col divide-y divide-[hsl(var(--line)/0.6)] rounded-xl">
          {summaries.map((s) => (
            <Link
              key={s.friend.id}
              to={`/messages/${s.friend.id}`}
              className="flex items-center justify-between px-4 py-3 transition hover:bg-[hsl(var(--line)/0.25)] first:rounded-t-xl last:rounded-b-xl"
            >
              <div className="flex items-center gap-3">
                {s.friend.avatar_url ? (
                  <img src={s.friend.avatar_url} alt="" className="h-10 w-10 rounded-full object-cover" />
                ) : (
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[hsl(var(--accent))]/15 font-serif text-[hsl(var(--accent-dark))]">
                    {(s.friend.full_name ?? s.friend.username ?? '?').charAt(0).toUpperCase()}
                  </div>
                )}
                <div>
                  <p className="text-sm font-medium text-[hsl(var(--ink))]">
                    {s.friend.full_name || s.friend.username}
                  </p>
                  <p className="max-w-[220px] truncate text-xs text-[hsl(var(--ink-soft))]">
                    {s.lastMessage ?? 'এখনো কোনো মেসেজ নেই'}
                  </p>
                </div>
              </div>
              {s.unreadCount > 0 && (
                <span className="flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-[hsl(var(--accent))] px-1.5 text-xs font-semibold text-white">
                  {s.unreadCount}
                </span>
              )}
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
