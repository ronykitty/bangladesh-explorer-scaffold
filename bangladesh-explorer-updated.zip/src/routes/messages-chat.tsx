// src/routes/messages-chat.tsx
import { useEffect, useRef, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, Send, Loader2 } from 'lucide-react'
import { useConversation } from '@/hooks/use-messages'
import { useCurrentUser } from '@/hooks/use-current-user'
import { supabase } from '@/lib/supabase'

export default function ChatPage() {
  const { friendId } = useParams<{ friendId: string }>()
  const { userId } = useCurrentUser()
  const { messages, loading, sendMessage, markRead } = useConversation(friendId)
  const [text, setText] = useState('')
  const [friendName, setFriendName] = useState<string | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!friendId) return
    supabase
      .from('profiles')
      .select('username, full_name')
      .eq('id', friendId)
      .single()
      .then(({ data }) => setFriendName(data?.full_name || data?.username || null))
  }, [friendId])

  useEffect(() => {
    markRead()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages.length])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  async function handleSend(e: React.FormEvent) {
    e.preventDefault()
    const content = text
    setText('')
    try {
      await sendMessage(content)
    } catch {
      setText(content) // ব্যর্থ হলে টেক্সট ফেরত দিন, যাতে ইউজার হারিয়ে না ফেলে
    }
  }

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-lg flex-col">
      <div className="glass flex items-center gap-3 rounded-t-xl border-b border-[hsl(var(--line))] px-4 py-3">
        <Link to="/messages" className="text-[hsl(var(--ink-soft))] hover:text-[hsl(var(--ink))]">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <h1 className="font-serif text-base text-[hsl(var(--ink))]">{friendName ?? '...'}</h1>
      </div>

      <div className="glass flex-1 space-y-2 overflow-y-auto px-4 py-4">
        {loading && (
          <p className="flex items-center justify-center gap-2 text-sm text-[hsl(var(--ink-soft))]">
            <Loader2 className="h-4 w-4 animate-spin" /> লোড হচ্ছে...
          </p>
        )}
        {!loading && messages.length === 0 && (
          <p className="text-center text-sm text-[hsl(var(--ink-soft))]">
            এখনো কোনো মেসেজ নেই। প্রথম মেসেজটা পাঠিয়ে শুরু করুন 👋
          </p>
        )}
        {messages.map((m) => {
          const isMine = m.sender_id === userId
          return (
            <div key={m.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${
                  isMine
                    ? 'bg-[hsl(var(--accent))] text-white'
                    : 'bg-[hsl(var(--line)/0.4)] text-[hsl(var(--ink))]'
                }`}
              >
                {m.content}
              </div>
            </div>
          )
        })}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={handleSend}
        className="glass flex gap-2 rounded-b-xl border-t border-[hsl(var(--line))] px-4 py-3"
      >
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="মেসেজ লিখুন..."
          className="flex-1 rounded-full border border-[hsl(var(--line))] bg-transparent px-4 py-2 text-sm text-[hsl(var(--ink))] outline-none focus:border-[hsl(var(--accent))]"
        />
        <button
          type="submit"
          disabled={!text.trim()}
          className="flex items-center justify-center rounded-full bg-[hsl(var(--accent))] p-2.5 text-white transition hover:opacity-90 disabled:opacity-40"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  )
}
