// src/router.tsx
import { createBrowserRouter } from 'react-router-dom'

// --- layout & guards ---
import { AppLayout } from '@/components/layout/app-layout'
import { ProtectedRoute } from '@/components/auth/protected-route'
import { PublicOnlyRoute } from '@/components/auth/public-only-route'

// --- auth pages (no sidebar) ---
import LoginPage from '@/routes/auth/login'
import SignupPage from '@/routes/auth/signup'
import ForgotPasswordPage from '@/routes/auth/forgot-password'
import ResetPasswordPage from '@/routes/auth/reset-password'

// --- main app pages (rendered inside AppLayout via <Outlet />, behind auth) ---
import DashboardPage from '@/routes/dashboard'
import FriendsPage from '@/routes/friends'
import FindFriendsPage from '@/routes/find-friends'
import MessagesInboxPage from '@/routes/messages'
import MessagesChatPage from '@/routes/messages-chat'
import ProfilePage from '@/routes/profile'
import CategoryPage from '@/routes/category'
import CategoryManagePage from '@/routes/category-manage'
import GalleryPage from '@/routes/gallery'
import JournalPage from '@/routes/journal'
import PlacesPage from '@/routes/places'
import PlannerPage from '@/routes/planner'
import SettingsPage from '@/routes/settings'
import WishlistPage from '@/routes/wishlist'

export const router = createBrowserRouter([
  // --- auth: only reachable when logged out, redirects to '/' if already logged in ---
  {
    element: <PublicOnlyRoute />,
    children: [
      { path: '/login', element: <LoginPage /> },
      { path: '/signup', element: <SignupPage /> },
      { path: '/forgot-password', element: <ForgotPasswordPage /> },
      { path: '/reset-password', element: <ResetPasswordPage /> },
    ],
  },

  // --- main app: requires login, wrapped in AppLayout (sidebar + topbar) ---
  {
    element: <ProtectedRoute />,
    children: [
      {
        path: '/',
        element: <AppLayout />,
        children: [
          { index: true, element: <DashboardPage /> },              // '/'
          { path: 'places', element: <PlacesPage /> },               // '/places'
          { path: 'gallery', element: <GalleryPage /> },             // '/gallery'
          { path: 'wishlist', element: <WishlistPage /> },           // '/wishlist'
          { path: 'planner', element: <PlannerPage /> },             // '/planner'
          { path: 'journal', element: <JournalPage /> },             // '/journal'
          { path: 'settings', element: <SettingsPage /> },           // '/settings'
          { path: 'friends', element: <FriendsPage /> },             // '/friends'
          { path: 'find-friends', element: <FindFriendsPage /> },    // '/find-friends'
          { path: 'messages', element: <MessagesInboxPage /> },      // '/messages'
          { path: 'messages/:friendId', element: <MessagesChatPage /> }, // '/messages/:friendId'
          { path: 'category/manage', element: <CategoryManagePage /> }, // must come before 'category/:slug'
          { path: 'category/:slug', element: <CategoryPage /> },     // '/category/heritage' etc.
          { path: 'profile/:username', element: <ProfilePage /> },   // '/profile/:username'
        ],
      },
    ],
  },
])
